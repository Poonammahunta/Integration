echo -e 'This is a sample execution output for coral status\n'
echo -e 'Coral\n'
ls -l