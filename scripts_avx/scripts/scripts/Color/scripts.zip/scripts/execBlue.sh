echo -e 'This is a sample execution output for blue status\n'
echo -e 'Blue\n'
ls -l