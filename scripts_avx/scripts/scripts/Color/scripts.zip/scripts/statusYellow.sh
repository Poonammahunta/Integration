echo Color:Yellow,Response:Yellow Color Code
