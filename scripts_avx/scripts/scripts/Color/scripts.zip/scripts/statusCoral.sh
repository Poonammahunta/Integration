echo Color:Coral,Response:Coral Color Code
