echo Color:Pink,Response:Pink Color Code
