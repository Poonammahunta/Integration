echo -e 'This is a sample execution output for aqua status\n'
echo -e 'aqua\n'
ls -l