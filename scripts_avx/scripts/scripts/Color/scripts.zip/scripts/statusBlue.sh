echo Color:Blue,Response:Blue Color Code
