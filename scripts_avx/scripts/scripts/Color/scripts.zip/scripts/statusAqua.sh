echo Color:Aqua,Response:Aqua Color Code
