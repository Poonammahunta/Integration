echo -e 'This is a sample execution output for yellow status\n'
echo -e 'Yellow\n'
ls -l