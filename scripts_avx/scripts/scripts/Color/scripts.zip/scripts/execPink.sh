echo -e 'This is a sample execution output for a Pink status\n'
echo -e 'Pink\n'
ls -l