echo Color:Fuchsia,Response:Fuchsia Color Code
