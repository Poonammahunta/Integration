echo -e 'This is a sample execution output for Ivory status\n'
echo -e 'Ivory\n'
ls -l