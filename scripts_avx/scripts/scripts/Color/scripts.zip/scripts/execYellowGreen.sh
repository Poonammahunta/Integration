echo -e 'This is a sample execution output for a YellowGreen status\n'
echo -e 'YellowGreen\n'
ls -l