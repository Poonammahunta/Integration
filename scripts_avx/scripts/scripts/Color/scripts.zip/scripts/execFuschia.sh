echo -e 'This is a sample execution output for Fuchsia status\n'
echo -e 'Fuchsia\n'
ls -l