echo Color:Ivory,Response:Ivory Color Code
