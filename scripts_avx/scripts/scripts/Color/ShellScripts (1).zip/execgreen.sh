echo Color:Green,Response:VIP enabled
