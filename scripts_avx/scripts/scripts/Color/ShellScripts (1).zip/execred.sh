echo Color:Red,Response:VIP disabled
